//document.body.style.background = "#000";
alert('这是一个扩展') 